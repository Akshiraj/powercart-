/*package com.niit.model;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class BillingAddress implements Serializable {

	
	private static final long serialVersionUID = -7655050509943176710L;
	
	private String doorNo;
	
	private String streetName;
	
	private String city;
	
	private String district;
	
	private long pinCode;

	public String getDoorNo() {
		return doorNo;
	}

	public void setDoorNo(String doorNo) {
		this.doorNo = doorNo;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public long getPinCode() {
		return pinCode;
	}

	public void setPinCode(long pinCode) {
		this.pinCode = pinCode;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
*/


