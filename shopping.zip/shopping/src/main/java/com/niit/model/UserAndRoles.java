package com.niit.model;

import java.io.Serializable;

public class UserAndRoles implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3297331572839915997L;
	
	private int userId;
	
	private int roleId;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getRoleId() {
		return roleId;
	}

	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
