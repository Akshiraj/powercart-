package com.niit.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Supplier implements Serializable {

	
	
    /**
	 * 
	 */
	private static final long serialVersionUID = -476739416866425322L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int Supplierid;

	public int getSupplierid() {
		return Supplierid;
	}

	public void setSupplierid(int supplierid) {
		Supplierid = supplierid;
	}

	public String getSuppliername() {
		return suppliername;
	}

	public void setSuppliername(String suppliername) {
		this.suppliername = suppliername;
	}

	public String getBusinessaddress() {
		return businessaddress;
	}

	public void setBusinessaddress(String businessaddress) {
		this.businessaddress = businessaddress;
	}

	public String getPostaladdress() {
		return postaladdress;
	}

	public void setPostaladdress(String postaladdress) {
		this.postaladdress = postaladdress;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private String suppliername;
    
    private String businessaddress;
	
	private String postaladdress;

	
	
}
