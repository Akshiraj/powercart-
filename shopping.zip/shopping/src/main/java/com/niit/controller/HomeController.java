package com.niit.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.niit.model.Category;
import com.niit.model.Product;
import com.niit.model.Regpage;
import com.niit.model.Supplier;
import com.niit.model.UploadedFile;


@Controller
public class HomeController {
	
	@RequestMapping("/")
	public String showHome(Model model){
		model.addAttribute("loginCheck","logout");
		return "Home";
	}
	
	@RequestMapping("/home")
	public String showHome_(@RequestParam("login") String login, Model model){
		System.out.println(login);
		if(login.equals("true")){
			System.out.println(login);
			model.addAttribute("loginCheck","login");
			return "Home";
		}
		else{
			System.out.println("Login Else");
			model.addAttribute("loginCheck","logout");
			return "Home";
		}
	}
	

	@RequestMapping(value="/admin")
	public String getAdmin(){
		return "admin";	
		}
	
	/*@RequestMapping(value="/showProducts")
	public String geProducts(){
		return "showProducts";	
		}
*/
	
	@RequestMapping("/login")
	public String LoginPage(){
		
		return "login";
	}
	
	@RequestMapping("/logout")
	public String LogPage(){
		
		return "login";
	}
	
	
	@ModelAttribute("register")
	public Regpage getUserView(){
		return new Regpage();
	}
	
	@RequestMapping(value="/register")
	public String getUser(){
		return "index";	
		}
	
	/*
	@ModelAttribute("saveCategory")
	public Category getCategoryCmd(){
		return new Category();
	}
	
	@RequestMapping(value="/saveCategory")
	public String saveCategoryMtd(){
		return "Category";
	}
	*/
	@ModelAttribute("updateCategory")
	public Category getCategory(){
		return new Category();
	}
	
	@RequestMapping(value="/updateCategory")
	public String updateCategoryMtd(){
		return "Category";
	}
	
	@ModelAttribute("addProduct")
	public Product getProductCmd(){
		return new Product();
	}
	
	@RequestMapping(value="/addProduct")
	public String addProduct(){
		return "Product";
	}
	
	@ModelAttribute("editProduct")
	public Product getProduct(){
		return new Product();
	}
	
	@RequestMapping(value="/editProduct")
	public String editProduct(){
		return "Product";
	}
	
	@ModelAttribute("addSupplier")
	public Supplier getSupplierCmd(){
		return new Supplier();
	}
	
	@RequestMapping(value="/addSupplier")
	public String addsupplier(){
		return "Supplier";
	}

	@ModelAttribute("editSupplier")
	public Supplier getSupplier(){
		return new Supplier();
	}
	
	@RequestMapping(value="/editSupplier")
	public String editsupplier(){
		return "Supplier";
	}
	
	@ModelAttribute("deleteSupplier")
	public Supplier getSupplierCommand(){
		return new Supplier();
	}
	
	@RequestMapping(value="/deleteSupplier")
	public String deletesupplier(){
		return "Supplier";
	}
	
	@ModelAttribute("uploadedFile")
	public UploadedFile getUpload()
	{
		return new UploadedFile();
	}
	
	@RequestMapping("/fileUploadForm")
	public String getUploadForm()
	{
		return "uploadForm";
	}
	
	
	@RequestMapping("/cart")
	public String getCart()
	{
		return "cart";
	}
	
	}
	


