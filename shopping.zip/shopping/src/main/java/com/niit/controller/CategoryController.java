package com.niit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.model.Category;
import com.niit.services.CategoryService;


@Controller
public class CategoryController {
	
public CategoryService category_service;


@Autowired(required = true)
public void setCategoryDAO(CategoryService category_service) {
	this.category_service=category_service;
    
}

@ModelAttribute("saveCategory")
public Category getCategoryCmd(){
	return new Category();
}

@RequestMapping(value="/saveCategory",method=RequestMethod.POST)
public String savecategory(@ModelAttribute("saveCategory")Category category,BindingResult result){
	
	category_service.save(category);
	
	return "Category";
}

@ModelAttribute("updateCategory")
public Category getCategory(){
	return new Category();
}

@RequestMapping(value="/updateCategory",method=RequestMethod.POST)
public String updatecategory(@ModelAttribute("updateCategory")Category category,BindingResult result){
	
	category_service.update(category);
	
	return "Category";
}

}

