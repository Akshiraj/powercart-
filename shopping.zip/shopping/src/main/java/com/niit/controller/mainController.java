package com.niit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.DAO.RegDao;
import com.niit.model.Regpage;


@Controller
public class mainController {
	
	/*public  UserService userService;
	
	@Autowired(required=true)
	public void setUserDAO(UserService userService){
		this.userService=userService;
	}
	
	*/
	public RegDao regDao;
	
	@Autowired(required=true)
	public void setUserDAO(RegDao regDao){
		this.regDao=regDao;
	}
	
	
	@ModelAttribute("register")
	public Regpage getUserView(){
		return new Regpage();
	}
	
	@RequestMapping(value="/register",method=RequestMethod.POST)
	public String getUser(@ModelAttribute("register")Regpage regpage,BindingResult result){
		
		regDao.save(regpage);
		
		return "index";	
		}
	
	
	
	}
	


