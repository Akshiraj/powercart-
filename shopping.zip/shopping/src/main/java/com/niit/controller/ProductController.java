package com.niit.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.niit.model.Product;
import com.niit.services.ProductService;


@Controller
public class ProductController {

	public ProductService product_service;
	
	@Autowired(required = true)
	public void setProductDAO(ProductService product_service) {
		this.product_service=product_service; 
	}
	
	@ModelAttribute("addProduct")
	public Product getProductCmd(){
		return new Product();
	}

	@RequestMapping(value="/addProduct",method=RequestMethod.POST)
	public String addproduct(@ModelAttribute("addProduct")Product product,BindingResult result){
		
		product_service.add(product);
		
		return "Product";
	}
	
	@ModelAttribute("editProduct")
	public Product getProduct(){
		return new Product();
	}

	@RequestMapping(value="/editProduct",method=RequestMethod.POST)
	public String editproduct(@ModelAttribute("editProduct")Product product,BindingResult result){
		
		product_service.edit(product);
		
		return "Product";
	}
	
	@RequestMapping("/showProducts")
	public String showProducts(Model model) {
		model.addAttribute("listProduct", this.product_service.getList());
		
		model.addAttribute("path","resource\\images\\");
		return "showProducts";
	}

	
}
