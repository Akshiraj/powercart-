package com.niit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.niit.model.Supplier;
import com.niit.services.supplierService;


@Controller
public class SupplierController {
	
	public supplierService supplier_service;

	@Autowired(required=true)
	public void setSupplierService(supplierService supplier_service)
	{
		this.supplier_service=supplier_service;
	}
	
	@ModelAttribute("addSupplier")
	public Supplier getSupplierCmd(){
		return new Supplier();
	}
	
	@RequestMapping(value="/addSupplier",method=RequestMethod.POST)
	public String addsupplier(@ModelAttribute("addSupplier")Supplier supplier,BindingResult result){
		
		supplier_service.add(supplier);
		
		return "Supplier";
	}

	@ModelAttribute("editSupplier")
	public Supplier getSupplier(){
		return new Supplier();
	}
	
	@RequestMapping(value="/editSupplier",method=RequestMethod.POST)
	public String editsupplier(@ModelAttribute("editSupplier")Supplier supplier,BindingResult result){
		
		supplier_service.edit(supplier);
		
		return "Supplier";
	}
	
	@ModelAttribute("deleteSupplier")
	public Supplier getSupplierCommand(){
		return new Supplier();
	}
	
	@RequestMapping(value="/deleteSupplier",method=RequestMethod.POST)
	public String deleteSupplier(@ModelAttribute("deleteSupplier")Supplier supplier,BindingResult result){
		
		supplier_service.delete(supplier);
		
		return "Supplier";
	}
}
