package com.niit.DAO;

import com.niit.model.User;

public interface UserDao {
	
	  public  void save(User user);
		
		public void update(User user);
	
	   public  User findUser(int userId);
		
		public User findUserByName(String username);
		
		 
		
}


