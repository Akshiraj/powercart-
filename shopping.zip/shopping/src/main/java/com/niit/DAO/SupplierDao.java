package com.niit.DAO;

import com.niit.model.Supplier;

public interface SupplierDao {
	
	
	public void add(Supplier supplier);
	
	public void edit(Supplier supplier);
	
	public void delete(Supplier supplier);

	public void fetchAll();

}
