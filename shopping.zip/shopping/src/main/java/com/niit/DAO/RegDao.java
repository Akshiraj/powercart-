package com.niit.DAO;
import java.util.List;

import com.niit.model.Regpage;




public interface RegDao {
	
		public void save(Regpage regpage);
		
		public void update(Regpage regpage);
		
		 public List<Regpage> getList();
		 
	}



