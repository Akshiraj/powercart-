package com.niit.services.Impl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.DAO.SupplierDao;
import com.niit.model.Supplier;
import com.niit.services.supplierService;

@Service("supplierService")
public class supplierServiceImpl implements supplierService {

	
	@Autowired
	private SupplierDao supplierDao;
	
	public void add(Supplier supplier) {
		supplierDao.add(supplier);
		
	}

	public void edit(Supplier supplier) {
		supplierDao.edit(supplier);
		
	}

	public void delete(Supplier supplier) {
		supplierDao.delete(supplier);
		
	}
	
	}

	
