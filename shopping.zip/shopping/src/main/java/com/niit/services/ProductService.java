package com.niit.services;

import java.util.List;

import com.niit.model.Product;

public interface ProductService {

	public void add(Product product);
	
	public void edit(Product product);
	
	public List<Product> getList();
	
	public Product getProductById(int id);

}
