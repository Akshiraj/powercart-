package com.niit.services;

import com.niit.model.Supplier;

  public interface supplierService {
	
	  public void add(Supplier supplier);
		
		public void edit(Supplier supplier);
		
		public void delete(Supplier supplier);

}
