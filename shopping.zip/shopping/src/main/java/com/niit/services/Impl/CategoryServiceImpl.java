package com.niit.services.Impl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.DAO.CategoryDAO;
import com.niit.model.Category;
import com.niit.services.CategoryService;


@Service("CategoryService")
public class CategoryServiceImpl implements CategoryService {

	
	@Autowired
	private CategoryDAO categoryDAO;

	public void save(Category category) {
		categoryDAO.save(category);
		
	}

	public void update(Category category) {
		categoryDAO.update(category);
		
	}

	public List<Category> list() {
		
		return this.categoryDAO.list();
	}

	public void fetchAll() {
		// TODO Auto-generated method stub
		
	}
	
	}

	
