package com.niit.services;

import java.util.List;

import com.niit.model.Regpage;



public interface regService {
	
	public void save(Regpage regpage);
	
	public void update(Regpage regpage);
	
	 public List<Regpage> getList();
}
