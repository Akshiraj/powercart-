package com.niit.services.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.DAO.RegDao;
import com.niit.model.Regpage;
import com.niit.services.regService;


@Service("service")
public class RegServiceImple implements regService {
	
	@Autowired
	private RegDao regDao;

	public void save(Regpage regpage) {
		regDao.save(regpage);
		
	}

	public void update(Regpage regpage) {
		
		regDao.update(regpage);
	}

	public List<Regpage> getList() {
		return this.regDao.getList();
	}

	

}
