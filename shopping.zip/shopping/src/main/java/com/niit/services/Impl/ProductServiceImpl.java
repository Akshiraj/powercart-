package com.niit.services.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.DAO.ProductDao;
import com.niit.model.Product;
import com.niit.services.ProductService;

@Service("ProductService")
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	private ProductDao productDao;

	public void add(Product product) {
		productDao.add(product);
		
	}

	public void edit(Product product) {
		
		productDao.edit(product);
	}

	public List<Product> getList() {
		
		return this.productDao.getList();
	}

	public Product getProductById(int id) {
		
		return this.productDao.getProductById(id);
	}


}
