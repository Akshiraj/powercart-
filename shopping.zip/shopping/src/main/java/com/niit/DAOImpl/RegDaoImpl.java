package com.niit.DAOImpl;

import java.util.List;

import org.hibernate.Session;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.niit.DAO.RegDao;
import com.niit.model.Regpage;



@Repository
@Transactional
public class RegDaoImpl implements RegDao {

	@Autowired
	public SessionFactory sessionFactory;

	public SessionFactory getSeesionFactory (SessionFactory sessionFactory) {
		 return this.sessionFactory = sessionFactory;
	}

	

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void save(Regpage regpage) {
		
		Session session = sessionFactory.openSession();
		System.out.println("the save method is started and session is opened");
		Transaction tx = (Transaction) session.beginTransaction();
		session.saveOrUpdate(regpage);
		tx.commit();
		session.close();

	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void update(Regpage regpage) {
	
		Session session = sessionFactory.openSession();
		System.out.println("the update method is started and session is opened");
		Transaction tx = (Transaction) session.beginTransaction();
		session.update(regpage);
		tx.commit();
		session.close();
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public List<Regpage> getList() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		@SuppressWarnings("unchecked")
		 List<Regpage> userList = session.createQuery("from User").list();
		session.close();
		return userList;
	}

}
