	package com.niit.DAOImpl;

	import java.util.List;

import org.hibernate.Session;
	import org.hibernate.SessionFactory;
	import org.hibernate.Transaction;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Repository;
	import org.springframework.transaction.annotation.Propagation;
	import org.springframework.transaction.annotation.Transactional;

import com.niit.DAO.ProductDao;
import com.niit.model.Product;

	
	@Repository
	public class ProductDaoImpl implements ProductDao {
		
		
		@Autowired
		private SessionFactory sessionFactory;
		
		public SessionFactory getSession(SessionFactory sessionFactory){
			return this.sessionFactory=sessionFactory;
		}
		
		@Transactional(propagation=Propagation.SUPPORTS,readOnly=false)
		public void add(Product product) {
			// TODO Auto-generated method stub
			Session session = sessionFactory.openSession();
			Transaction transaction = (Transaction) session.beginTransaction();
			session.saveOrUpdate(product);
			transaction.commit();
			session.close();	
		}
		
		@Transactional(propagation=Propagation.SUPPORTS,readOnly=false)
		public void edit(Product product) {
			// TODO Auto-generated method stub
			Session session = sessionFactory.openSession();
			Transaction transaction = (Transaction) session.beginTransaction();
			session.update(product);
			transaction.commit();
			session.close();	
		}

			@SuppressWarnings("unchecked")
			@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
			public List<Product> getList() {
				Session session = sessionFactory.openSession();
				List<Product> proList = session.createQuery("from Product").list();
				return proList;
			}

			@SuppressWarnings("unused")
			public Product getProductById(int id) {
				Session session = this.sessionFactory.openSession();
				Transaction transaction = session.beginTransaction();
				Product product = (Product) session.load(Product.class,id);
				return product;
			}

		}
		
	

