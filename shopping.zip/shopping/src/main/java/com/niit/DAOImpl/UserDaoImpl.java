package com.niit.DAOImpl;


import org.hibernate.Criteria;
import org.hibernate.Session;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.niit.DAO.UserDao;
import com.niit.model.User;

@Repository
public class UserDaoImpl implements UserDao {

	@Autowired
	public SessionFactory sessionFactory;

	public SessionFactory getSeesionFactory (SessionFactory sessionFactory) {
		 return this.sessionFactory = sessionFactory;
	}

	

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void save(User user) {
		Session session = sessionFactory.openSession();
		System.out.println("the save method is started and session is opened");
		Transaction tx = (Transaction) session.beginTransaction();
		session.saveOrUpdate(user);
		tx.commit();
		session.close();

	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void update(User user) {
	    Session session = sessionFactory.openSession();
		System.out.println("the update method is started and session is opened");
		Transaction tx = (Transaction) session.beginTransaction();
		session.update(user);
		tx.commit();
		session.close();
	}



	/*@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public List<User> list() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		@SuppressWarnings("unchecked")
		 List<User> userList = session.createQuery("from User").list();
		session.close();
		return userList;
	}
*/
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void delete(User user) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		System.out.println("the delete method is started and session is opened");
		Transaction tx = (Transaction) session.beginTransaction();
		session.delete(user);
		tx.commit();
		session.close();
		
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public User findUser(int userId) {
		
		/*Session session = sessionFactory.openSession();
		System.out.println("the finduser method is started and session is opened");
		Transaction tx = (Transaction) session.beginTransaction();
		session.get(User.class,userId);
		tx.commit();
		*/
		
		return (User) sessionFactory.openSession().get(User.class,userId);
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public User findUserByName(String username) {
		/*Session session = sessionFactory.openSession();
		System.out.println("the finduserByName method is started and session is opened");
		Transaction tx = (Transaction) session.beginTransaction();
		User user=(User)session.load(User.class,username);
		tx.commit();
		session.close();
	    return user;
	    */
		Criteria criteria= sessionFactory.openSession().createCriteria(User.class);
		criteria.add(Restrictions.eq("username",username));
		return (User) criteria.uniqueResult();	
	}

}
