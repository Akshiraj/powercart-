package com.niit.DAOImpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.niit.DAO.SupplierDao;
import com.niit.model.Supplier;



	@Repository
	public class SupplierDaoImpl implements SupplierDao {

		@Autowired
		private SessionFactory sessionFactory;
		
		public SessionFactory getSession(SessionFactory sessionFactory){
			return this.sessionFactory=sessionFactory;
		}
		
		@Transactional(propagation=Propagation.SUPPORTS,readOnly=false)
		public void add(Supplier supplier) {
			Session session = sessionFactory.openSession();
			Transaction transaction = (Transaction) session.beginTransaction();
			session.saveOrUpdate(supplier);
			transaction.commit();
			session.close();
		}
		
		@Transactional(propagation=Propagation.SUPPORTS,readOnly=false)
		public void edit(Supplier supplier) {
			// TODO Auto-generated method stub
			Session session = sessionFactory.openSession();
			Transaction transaction = (Transaction) session.beginTransaction();
			session.update(supplier);
			transaction.commit();
			session.close();		
		}

		@Transactional(propagation=Propagation.SUPPORTS,readOnly=false)
		public void delete(Supplier supplier) {
			// TODO Auto-generated method stub
			Session session = sessionFactory.openSession();
			Transaction transaction = (Transaction) session.beginTransaction();
			session.delete(supplier);
			transaction.commit();
			session.close();
		}
		
		public void fetchAll() {
			// TODO Auto-generated method stub
			
		}

		
		
}
