floatlabels.js
==============

Follows the famous Float Label Pattern. Built on jQuery.

Demo / Documentation:  
http://probots-io.github.io/floatlabels.js/
